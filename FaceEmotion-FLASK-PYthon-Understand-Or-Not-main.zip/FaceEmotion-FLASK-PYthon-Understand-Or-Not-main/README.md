# FaceEmotion-FLASK-PYthon-Understand-Or-Not
DL,Keras,CV2,CNN,Flask, Python
This project aims to develop a solution for facial expressions recognizing of students in the class. In this project, we are presenting the real-time facial expression recognition of two human expressions: Understanding or not.
We started with dataset fer2013 to train our model(CNN). The data consists of 48x48 pixel grayscale.
The objective is to classify each face based on the emotion shown in the facial expression into one of five categories (Angry,Happy,Sad,Surprise,Neutral).we based on adopted VGG (VGG 16 + 19 ) achieving 60% accuracy.
We collected our own dataset (thanks to my friends and my classmates) to apply transfer learning and data Augmentation.
#Keras #TransferLearning #DataAugmentation #VGG #OpenCV#
[Simulation](https://www.linkedin.com/feed/update/urn:li:activity:6684572394465583104/)

